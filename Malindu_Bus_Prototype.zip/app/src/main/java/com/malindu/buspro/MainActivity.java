package com.malindu.buspro;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Locale;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    private GameView gameView;
    private GameRenderer renderer;
    private TextView hud;
    private Button fireButton;
    private ToneGenerator horn;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894 | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        prefs = getSharedPreferences("bus_pro_progress", MODE_PRIVATE);
        renderer = new GameRenderer(this);
        renderer.coins = prefs.getInt("coins", 0);
        renderer.distance = prefs.getFloat("distance", 0f);
        gameView = new GameView(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(12, 22, 36));
        root.addView(gameView, new FrameLayout.LayoutParams(-1,-1));
        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        hud.setTextSize(15);
        hud.setPadding(dp(14),dp(8),dp(14),dp(8));
        hud.setBackground(shape(0xBE081727, 20));
        hud.setText("MALINDU BUS PRO 3D\nLoading 3D world...");
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(dp(292),-2,Gravity.TOP|Gravity.LEFT);
        hp.leftMargin=dp(12);hp.topMargin=dp(10);
        root.addView(hud,hp);

        addButton(root,"◀",Gravity.BOTTOM|Gravity.LEFT,14,20,72,70,true,1,null);
        addButton(root,"▶",Gravity.BOTTOM|Gravity.LEFT,96,20,72,70,true,2,null);
        addButton(root,"BRAKE",Gravity.BOTTOM|Gravity.RIGHT,140,20,93,70,true,3,null);
        addButton(root,"GO",Gravity.BOTTOM|Gravity.RIGHT,24,20,99,70,true,4,null);
        fireButton=addButton(root,"FIRE",Gravity.BOTTOM|Gravity.RIGHT,250,20,92,70,false,0,()->{ renderer.fire(); });
        fireButton.setVisibility(View.GONE);
        addButton(root,"ACTION",Gravity.TOP|Gravity.RIGHT,12,12,92,48,false,0,()->{
            renderer.action=!renderer.action;
            fireButton.setVisibility(renderer.action?View.VISIBLE:View.GONE);
        });
        addButton(root,"CAMERA",Gravity.TOP|Gravity.RIGHT,112,12,92,48,false,0,()->{renderer.cockpit=!renderer.cockpit;});
        addButton(root,"NIGHT",Gravity.TOP|Gravity.RIGHT,212,12,78,48,false,0,()->{renderer.night=!renderer.night;});
        addButton(root,"PAINT",Gravity.TOP|Gravity.RIGHT,298,12,78,48,false,0,()->{renderer.paint=(renderer.paint+1)%4;});
        addButton(root,"HORN",Gravity.BOTTOM|Gravity.LEFT,180,20,80,60,false,0,()->{
            if(horn==null)horn=new ToneGenerator(AudioManager.STREAM_MUSIC,75);
            horn.startTone(ToneGenerator.TONE_PROP_BEEP2,220);
        });
        addButton(root,"RESET",Gravity.BOTTOM|Gravity.LEFT,270,20,80,60,false,0,()->renderer.reset());
        setContentView(root);
    }
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable shape(int color, int radius){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{color,color});
        g.setCornerRadius(dp(radius));g.setStroke(dp(1),0x8A77B9FF);return g;
    }
    private Button addButton(FrameLayout root,String title,int gravity,int marginX,int marginY,int w,int h,boolean hold,int control,Runnable onClick){
        Button btn=new Button(this);
        btn.setText(title);btn.setTextColor(Color.WHITE);btn.setTextSize(title.length()>5?11:17);
        btn.setTypeface(Typeface.DEFAULT,Typeface.BOLD);btn.setAllCaps(false);
        btn.setPadding(0,0,0,0);btn.setBackground(shape(title.equals("FIRE")?0xE5AE3039:0xD5122B4A,17));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(w),dp(h),gravity);
        if((gravity&Gravity.RIGHT)==Gravity.RIGHT)lp.rightMargin=dp(marginX);else lp.leftMargin=dp(marginX);
        if((gravity&Gravity.BOTTOM)==Gravity.BOTTOM)lp.bottomMargin=dp(marginY);else lp.topMargin=dp(marginY);
        root.addView(btn,lp);
        if(hold){btn.setOnTouchListener((v,event)->{
            int a=event.getActionMasked();
            if(a==MotionEvent.ACTION_DOWN){renderer.setControl(control,true);return true;}
            if(a==MotionEvent.ACTION_UP || a==MotionEvent.ACTION_CANCEL){renderer.setControl(control,false);return true;}
            return true;
        });}
        else if(onClick!=null)btn.setOnClickListener(v->onClick.run());
        return btn;
    }
    @Override protected void onPause(){super.onPause();if(gameView!=null)gameView.onPause();save();}
    @Override protected void onResume(){super.onResume();if(gameView!=null)gameView.onResume();}
    @Override protected void onDestroy(){super.onDestroy();save();if(horn!=null)horn.release();}
    private void save(){if(renderer!=null && prefs!=null)prefs.edit().putInt("coins",renderer.coins).putFloat("distance",renderer.distance).apply();}
    private final class GameView extends GLSurfaceView {
        GameView(Context c){super(c);setEGLContextClientVersion(2);setPreserveEGLContextOnPause(true);setRenderer(renderer);setRenderMode(RENDERMODE_CONTINUOUSLY);}
    }

    private static class GameRenderer implements GLSurfaceView.Renderer {
        private final MainActivity activity;
        volatile boolean left,right,gas,brake,action,cockpit,night;
        volatile int paint=0;
        volatile int coins=0;
        volatile float distance=0;
        volatile float speed=0,busX=0,busZ=0,heading=0;
        private float last=0,clock=0,hitFlash=0;
        private int targets=0;
        private long lastHud=0;
        private int program,positionAttr,shadeAttr,mvpUniform,colorUniform;
        private FloatBuffer cube;
        private final float[] model=new float[16],view=new float[16],projection=new float[16],mv=new float[16],mvp=new float[16];
        private final float[][] bodyColors={{0.88f,0.12f,0.20f},{0.07f,0.38f,0.87f},{0.95f,0.68f,0.08f},{0.20f,0.80f,0.53f}};
        GameRenderer(MainActivity a){activity=a;}
        void setControl(int code,boolean held){switch(code){case 1:left=held;break;case 2:right=held;break;case 3:brake=held;break;case 4:gas=held;break;}}
        void reset(){speed=0;heading=0;busX=0;busZ=0;}
        void fire(){if(action){targets++;coins+=125;hitFlash=0.18f;}}
        @Override public void onSurfaceCreated(GL10 unused,EGLConfig config){
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            GLES20.glEnable(GLES20.GL_CULL_FACE);
            GLES20.glCullFace(GLES20.GL_BACK);
            GLES20.glClearDepthf(1f);
            String vs="uniform mat4 uMvp;attribute vec3 aPosition;attribute float aShade;varying float vShade;void main(){vShade=aShade;gl_Position=uMvp*vec4(aPosition,1.0);}";
            String fs="precision mediump float;varying float vShade;uniform vec4 uColor;void main(){gl_FragColor=vec4(uColor.rgb*vShade,uColor.a);}";
            int v=shader(GLES20.GL_VERTEX_SHADER,vs), f=shader(GLES20.GL_FRAGMENT_SHADER,fs);
            program=GLES20.glCreateProgram();GLES20.glAttachShader(program,v);GLES20.glAttachShader(program,f);GLES20.glLinkProgram(program);
            positionAttr=GLES20.glGetAttribLocation(program,"aPosition");shadeAttr=GLES20.glGetAttribLocation(program,"aShade");
            mvpUniform=GLES20.glGetUniformLocation(program,"uMvp");colorUniform=GLES20.glGetUniformLocation(program,"uColor");
            createCube();
            GLES20.glUseProgram(program);
            cube.position(0);GLES20.glVertexAttribPointer(positionAttr,3,GLES20.GL_FLOAT,false,16,cube);GLES20.glEnableVertexAttribArray(positionAttr);
            cube.position(3);GLES20.glVertexAttribPointer(shadeAttr,1,GLES20.GL_FLOAT,false,16,cube);GLES20.glEnableVertexAttribArray(shadeAttr);
            GLES20.glDepthFunc(GLES20.GL_LEQUAL);
            last=SystemClock.uptimeMillis()/1000f;
        }
        private int shader(int type,String source){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,source);GLES20.glCompileShader(s);return s;}
        private void createCube(){
            float[][][] faces={
                {{-.5f,-.5f,.5f},{.5f,-.5f,.5f},{.5f,.5f,.5f},{-.5f,.5f,.5f}},
                {{.5f,-.5f,-.5f},{-.5f,-.5f,-.5f},{-.5f,.5f,-.5f},{.5f,.5f,-.5f}},
                {{.5f,-.5f,.5f},{.5f,-.5f,-.5f},{.5f,.5f,-.5f},{.5f,.5f,.5f}},
                {{-.5f,-.5f,-.5f},{-.5f,-.5f,.5f},{-.5f,.5f,.5f},{-.5f,.5f,-.5f}},
                {{-.5f,.5f,.5f},{.5f,.5f,.5f},{.5f,.5f,-.5f},{-.5f,.5f,-.5f}},
                {{-.5f,-.5f,-.5f},{.5f,-.5f,-.5f},{.5f,-.5f,.5f},{-.5f,-.5f,.5f}}};
            float[] shade={.92f,.68f,.78f,.76f,1.00f,.60f};
            cube=ByteBuffer.allocateDirect(36*4*4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            int[] ix={0,1,2,0,2,3};
            for(int i=0;i<6;i++)for(int j=0;j<6;j++){float[] p=faces[i][ix[j]];cube.put(p[0]).put(p[1]).put(p[2]).put(shade[i]);}
            cube.position(0);
        }
        @Override public void onSurfaceChanged(GL10 gl,int w,int h){
            GLES20.glViewport(0,0,w,h);
            Matrix.perspectiveM(projection,0,65,(float)w/Math.max(1,h),.1f,650f);
        }
        @Override public void onDrawFrame(GL10 gl){
            float now=SystemClock.uptimeMillis()/1000f;
            float dt=Math.max(0.005f,Math.min(0.045f,now-last));last=now;clock+=dt;
            if(gas)speed=Math.min(35f,speed+9f*dt);
            if(brake)speed=Math.max(0,speed-21f*dt);
            if(!gas&&!brake)speed=Math.max(0,speed-2.5f*dt);
            if(left)heading-=(.42f+speed*.016f)*dt;
            if(right)heading+=(.42f+speed*.016f)*dt;
            busX+=(float)Math.sin(heading)*speed*dt;
            busZ+=(float)Math.cos(heading)*speed*dt;
            distance+=speed*dt;
            if(Math.abs(busX)>95){busX=Math.signum(busX)*95;speed*=.95f;}
            if(distance>0 && ((int)distance/700)>((int)(distance-speed*dt)/700))coins+=500;
            hitFlash=Math.max(0,hitFlash-dt);
            if(night)GLES20.glClearColor(.015f,.035f,.085f,1);
            else GLES20.glClearColor(.32f,.68f,.90f,1);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
            float s=(float)Math.sin(heading),c=(float)Math.cos(heading);
            if(cockpit){
                Matrix.setLookAtM(view,0,busX+s*1.2f,3.25f,busZ+c*1.2f,
                    busX+s*27,2.9f,busZ+c*27,0,1,0);
            }else{
                Matrix.setLookAtM(view,0,busX-s*16,8.8f,busZ-c*16,
                    busX+s*9,1.4f,busZ+c*9,0,1,0);
            }
            GLES20.glUseProgram(program);
            paintWorld();
            if(!cockpit)paintBus();
            else paintCockpit();
            if(hitFlash>0) {
                float k=hitFlash/.18f;
                box(busX+s*5,2.3f,busZ+c*5,.65f,.65f,.65f,0,1f,.7f*.7f,.08f);
            }
            long t=SystemClock.uptimeMillis();
            if(t-lastHud>190){lastHud=t; final String state=String.format(Locale.US,
                "MALINDU BUS PRO 3D   |   %s\nSPEED %03.0f KM/H     RS %d     %s\nDIST %.1f KM     TARGETS %d     MISSION +Rs500 / 700m",
                action?"ACTION MODE":"DRIVE MODE",speed*3.6,coins,night?"NIGHT":"DAY",distance/1000,targets);
                activity.runOnUiThread(()->activity.hud.setText(state));
            }
        }
        private void paintWorld(){
            float pivot=(float)Math.floor(busZ/120)*120f;
            box(0,-.45f,pivot,380,.45f,420,0,.23f,.45f,.25f);
            box(0,-.17f,pivot,12,.11f,430,0,.15f,.18f,.23f);
            box(-6.6f,-.08f,pivot,1.2f,.12f,430,0,.67f,.66f,.63f);
            box(6.6f,-.08f,pivot,1.2f,.12f,430,0,.67f,.66f,.63f);
            for(int i=-12;i<=14;i++){
                float z=pivot+i*12;
                box(0,-.06f,z,.15f,.03f,5.2f,0,.96f,.82f,.48f);
            }
            for(int i=-7;i<=14;i++){
                float z=pivot+i*18f;
                for(int side=-1;side<=1;side+=2){
                    float x=side*(14+(i%3)*2.3f);
                    int n=Math.abs(i*73+side*17);
                    float tall=5+(n%9)*1.8f;
                    float br=.32f+(n%5)*.08f;
                    box(x,tall*.5f-.22f,z,7,tall,10,0,br,.48f,br+.06f);
                    box(x,tall*.5f+1,z+5.02f,4,.65f,.08f,0,.12f,.24f,.34f);
                    if(i%3==0){
                        box(side*9,1.25f,z+7,.52f,2.7f,.52f,0,.39f,.27f,.16f);
                        box(side*9,3.6f,z+7,3.5f,3.8f,3.5f,0,.10f,.37f,.16f);
                    }
                }
            }
            for(int i=-3;i<=5;i++){
                float z=busZ+i*35f+((i%2)*10);
                float hillX=(i%2==0?70:-70);
                box(hillX,8,z,65,16,45,0,.25f,.44f,.24f);
            }
            for(int i=0;i<8;i++){
                float z=busZ+(i*34+24-(clock*3)%60);
                float lane=(i%2==0?3f:-3f);
                paintCar(lane,z,i%3);
                if(i==0 && Math.abs(busZ-z)<5 && Math.abs(busX-lane)<2.2f) speed*=.93f;
            }
            if(action) {
                for(int i=0;i<4;i++){
                    float z=busZ+25+i*18;
                    float x=(i%2==0?3.5f:-3.5f);
                    box(x,1.8f,z,1.5f,3.6f,1.5f,0,.78f,.12f,.18f);
                    box(x,3.95f,z,1f,.9f,1f,0,.95f,.69f,.10f);
                }
            }
        }
        private void paintCar(float x,float z,int color){
            float r=color==0?.65f:.12f,g=color==1?.58f:.25f,b=color==2?.74f:.31f;
            box(x,.85f,z,2,1.25f,3.8f,0,r,g,b);
            box(x,1.65f,z-.2f,1.7f,.7f,2.1f,0,.11f,.22f,.29f);
            box(x-.85f,.32f,z-1.1f,.40f,.65f,.88f,0,.05f,.05f,.06f);
            box(x+.85f,.32f,z+1.1f,.40f,.65f,.88f,0,.05f,.05f,.06f);
        }
        private void local(float lx,float ly,float lz,float sx,float sy,float sz,float r,float g,float b){
            float cs=(float)Math.cos(heading),sn=(float)Math.sin(heading);
            box(busX+lx*cs+lz*sn,ly,busZ-lx*sn+lz*cs,sx,sy,sz,(float)Math.toDegrees(heading),r,g,b);
        }
        private void paintBus(){
            float[] body=bodyColors[paint];
            local(0,1.7f,0,3.5f,2.9f,8.0f,body[0],body[1],body[2]);
            local(0,3.34f,0,3.35f,.25f,8.1f,.93f,.92f,.84f);
            local(0,2.58f,4.05f,3.05f,1.5f,.09f,.08f,.19f,.27f);
            local(0,1.2f,4.10f,3.1f,.58f,.14f,.17f,.22f,.29f);
            for(int side=-1;side<=1;side+=2){
                for(int i=0;i<4;i++)local(side*1.80f,2.6f,-2.7f+i*1.7f,.08f,1.25f,1.35f,.08f,.22f,.30f);
                for(int i=0;i<2;i++)local(side*1.6f,.60f,-2.7f+i*5.4f,.45f,1.05f,1.10f,.06f,.07f,.08f);
                local(side*1.25f,1.2f,4.18f,.58f,.42f,.15f,.98f,.88f,.49f);
                local(side*1.3f,1.1f,-4.12f,.6f,.42f,.1f,.9f,.18f,.15f);
            }
            local(0,1.65f,4.17f,2.3f,.34f,.09f,.97f,.81f,.21f);
            local(0,.48f,0,3.5f,.4f,8.3f,.12f,.13f,.16f);
        }
        private void paintCockpit(){
            float s=(float)Math.sin(heading),c=(float)Math.cos(heading);
            box(busX+s*2.4f,2.4f,busZ+c*2.4f,2.9f,.48f,1.1f,(float)Math.toDegrees(heading),.11f,.15f,.20f);
        }
        private void box(float x,float y,float z,float sx,float sy,float sz,float angle,float r,float g,float b){
            Matrix.setIdentityM(model,0);Matrix.translateM(model,0,x,y,z);
            if(angle!=0)Matrix.rotateM(model,0,angle,0,1,0);
            Matrix.scaleM(model,0,sx,sy,sz);
            Matrix.multiplyMM(mv,0,view,0,model,0);Matrix.multiplyMM(mvp,0,projection,0,mv,0);
            GLES20.glUniformMatrix4fv(mvpUniform,1,false,mvp,0);
            GLES20.glUniform4f(colorUniform,r,g,b,1f);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36);
        }
    }
}
