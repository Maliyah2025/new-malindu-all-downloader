# Malindu Bus Simulator Pro 3D — playable Android prototype

A native Android OpenGL ES 2.0 3D bus-driving/action prototype. This is NOT the complete 54-feature simulator.

## Included
- Drivable stylized Sri Lankan-inspired bus, steering/gas/brake
- Third-person/cockpit perspectives
- Buildings, road, road markings, hills, trees and moving traffic
- Arcade ACTION mode with FIRE targets and score
- Day/night toggle, bus paint color toggle, horn, reset
- Speed, score, cash, distance and mission HUD, local progress storage
- Landscape touch-screen controls, 100% offline, no permissions or ads

## Not included
Detailed realistic bus physics, city-scale maps, actual Sri Lankan map assets, manual gears, full passenger systems, garage UI, advanced AI, weapon models, comprehensive damage/repair, full 54-feature scope.

## GitHub Actions
Commit source files on `bus-game` branch; `.github/workflows/bus-android.yml` builds debug APK, stores it as an artifact. Requires GitHub Actions access.
