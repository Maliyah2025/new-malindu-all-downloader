package com.malindu.pdfpro

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Offline bitmap PDF surface with vector-like, normalized, auto-saved ink. */
class InkPageView(ctx: Context) : View(ctx) {
    var mode: String = "move"
    var nightMode: Boolean = false
        set(value) { field = value; invalidate() }
    var penColor: Int = Color.rgb(49, 95, 234)
    var strokeSize: Float = 4f
    var rotation: Int = 0
        set(value) { field = ((value % 360) + 360) % 360; invalidate() }
    var onInkChanged: ((List<InkStroke>) -> Unit)? = null
    var onPageSwipe: ((Int) -> Unit)? = null
    var onTextRequested: ((PointF) -> Unit)? = null

    private var pageBitmap: Bitmap? = null
    private var strokes = mutableListOf<InkStroke>()
    private val undo = java.util.ArrayDeque<List<InkStroke>>()
    private val redo = java.util.ArrayDeque<List<InkStroke>>()
    private var current: InkStroke? = null
    private val pageMatrix = Matrix()
    private val inverse = Matrix()
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var startX = 0f
    private var startY = 0f
    private var lastTapTime = 0L
    private val scaleGesture = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoom = (zoom * detector.scaleFactor).coerceIn(1f, 5f)
            if (zoom == 1f) { panX = 0f; panY = 0f }
            invalidate()
            return true
        }
    })

    fun setPage(bitmap: Bitmap, pageStrokes: MutableList<InkStroke>, pageRotation: Int) {
        pageBitmap?.takeIf { it !== bitmap }?.recycle()
        pageBitmap = bitmap
        strokes = pageStrokes
        rotation = pageRotation
        undo.clear(); redo.clear(); current = null
        zoom = 1f; panX = 0f; panY = 0f
        invalidate()
    }

    fun clearPage() {
        pageBitmap?.recycle(); pageBitmap = null
        strokes.clear(); undo.clear(); redo.clear(); current = null
        invalidate()
    }

    fun changeMode(tool: String) { mode = tool; invalidate() }
    fun resetZoom() { zoom = 1f; panX = 0f; panY = 0f; invalidate() }

    private fun remember() {
        undo.addLast(strokes.map { it.deepCopy() })
        if (undo.size > 40) undo.removeFirst()
        redo.clear()
    }

    fun undo() {
        if (undo.isEmpty()) return
        redo.addLast(strokes.map { it.deepCopy() })
        strokes = undo.removeLast().map { it.deepCopy() }.toMutableList()
        notifyChanged()
    }

    fun redo() {
        if (redo.isEmpty()) return
        undo.addLast(strokes.map { it.deepCopy() })
        strokes = redo.removeLast().map { it.deepCopy() }.toMutableList()
        notifyChanged()
    }

    fun addText(point: PointF, text: String) {
        if (text.isBlank()) return
        remember()
        strokes.add(InkStroke("text", penColor, strokeSize * 4, mutableListOf(point), text))
        notifyChanged()
    }

    private fun notifyChanged() {
        invalidate()
        onInkChanged?.invoke(strokes.map { it.deepCopy() })
    }

    private fun computeMatrix() {
        val b = pageBitmap ?: return
        val bw = b.width.toFloat()
        val bh = b.height.toFloat()
        pageMatrix.reset()
        pageMatrix.setRotate(rotation.toFloat(), bw / 2f, bh / 2f)
        val rotated = RectF(0f, 0f, bw, bh)
        pageMatrix.mapRect(rotated)
        val vw = width.toFloat().coerceAtLeast(1f)
        val vh = height.toFloat().coerceAtLeast(1f)
        val fit = min(vw / rotated.width(), vh / rotated.height()) * zoom
        pageMatrix.postTranslate(-rotated.left, -rotated.top)
        pageMatrix.postScale(fit, fit)
        pageMatrix.postTranslate((vw - rotated.width() * fit) / 2f + panX,
            (vh - rotated.height() * fit) / 2f + panY)
        pageMatrix.invert(inverse)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(227, 233, 246))
        val b = pageBitmap ?: return
        computeMatrix()
        canvas.save()
        canvas.concat(pageMatrix)
        val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        if (nightMode) bitmapPaint.colorFilter = ColorMatrixColorFilter(floatArrayOf(
            -1f,0f,0f,0f,255f,
            0f,-1f,0f,0f,255f,
            0f,0f,-1f,0f,255f,
            0f,0f,0f,1f,0f
        ))
        canvas.drawBitmap(b, 0f, 0f, bitmapPaint)
        strokes.forEach { drawStroke(canvas, it, b.width.toFloat(), b.height.toFloat()) }
        current?.let { drawStroke(canvas, it, b.width.toFloat(), b.height.toFloat()) }
        canvas.restore()
    }

    private fun relativePoint(x: Float, y: Float): PointF {
        computeMatrix()
        val points = floatArrayOf(x, y)
        inverse.mapPoints(points)
        val b = pageBitmap ?: return PointF(0.5f, 0.5f)
        return PointF((points[0] / b.width).coerceIn(0f, 1f),
            (points[1] / b.height).coerceIn(0f, 1f))
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (pageBitmap == null) return false
        scaleGesture.onTouchEvent(event)
        if (event.pointerCount > 1 || scaleGesture.isInProgress) {
            current = null
            invalidate()
            return true
        }
        val x = event.x; val y = event.y
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = x; startY = y; lastX = x; lastY = y
                if (mode == "move") {
                    val now = System.currentTimeMillis()
                    if (now - lastTapTime < 270L) {
                        zoom = if (zoom > 1.05f) 1f else 2f
                        if (zoom == 1f) { panX = 0f; panY = 0f }
                        invalidate()
                    }
                } else if (mode != "text" && mode != "eraser") {
                    current = InkStroke(mode, penColor, strokeSize,
                        mutableListOf(relativePoint(x, y)))
                } else if (mode == "eraser") {
                    eraseAt(relativePoint(x, y))
                }
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == "move") {
                    if (zoom > 1.01f) {
                        panX += x - lastX; panY += y - lastY
                        invalidate()
                    }
                } else if (mode == "eraser") {
                    eraseAt(relativePoint(x, y))
                } else if (mode != "text") {
                    val p = relativePoint(x, y)
                    val s = current
                    if (s != null) {
                        if (s.type in listOf("rect", "circle", "line", "arrow")) {
                            if (s.points.size == 1) s.points.add(p) else s.points[1] = p
                        } else {
                            val last = s.points.last()
                            if (hypot(last.x - p.x, last.y - p.y) > .001f) s.points.add(p)
                        }
                        invalidate()
                    }
                }
                lastX = x; lastY = y
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (mode == "move") {
                    lastTapTime = System.currentTimeMillis()
                    if (zoom <= 1.02f && abs(x - startX) > Ui.dp(context, 68) &&
                        abs(y - startY) < Ui.dp(context, 100)) {
                        onPageSwipe?.invoke(if (x < startX) +1 else -1)
                    }
                } else if (mode == "text") {
                    onTextRequested?.invoke(relativePoint(x, y))
                } else if (mode != "eraser") {
                    val s = current
                    if (s != null) {
                        val p = relativePoint(x, y)
                        if (s.points.size == 1) s.points.add(p)
                        remember()
                        strokes.add(s)
                        current = null
                        notifyChanged()
                    }
                }
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> { current = null; invalidate(); return true }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    private fun eraseAt(p: PointF) {
        val threshold = .025f / zoom
        val matches = strokes.indices.reversed().firstOrNull { i ->
            val points = strokes[i].points
            if (points.isEmpty()) false
            else if (points.size == 1) hypot(points[0].x - p.x, points[0].y - p.y) < threshold
            else points.zipWithNext().any { (a, b) -> segmentDistance(p, a, b) < threshold }
        }
        if (matches != null) {
            remember()
            strokes.removeAt(matches)
            notifyChanged()
        }
    }

    private fun segmentDistance(p: PointF, a: PointF, b: PointF): Float {
        val dx = b.x - a.x; val dy = b.y - a.y
        val mag = dx * dx + dy * dy
        val t = if (mag < .0000001f) 0f else (((p.x - a.x) * dx + (p.y - a.y) * dy) / mag).coerceIn(0f, 1f)
        return hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy))
    }

    companion object {
        /** Used by both the live reader and the annotated PDF export engine. */
        fun drawStroke(canvas: Canvas, stroke: InkStroke, w: Float, h: Float) {
            if (stroke.points.isEmpty()) return
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = stroke.color
                strokeWidth = max(1f, stroke.size * w / 700f)
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                if (stroke.type == "highlighter") {
                    alpha = 86
                    strokeWidth *= 4f
                }
            }
            val pts = stroke.points.map { PointF(it.x * w, it.y * h) }
            if (stroke.type == "text") {
                paint.style = Paint.Style.FILL
                paint.alpha = 255
                paint.textSize = (stroke.size * w / 420f).coerceAtLeast(8f)
                stroke.text.split('\n').forEachIndexed { i, line ->
                    canvas.drawText(line, pts[0].x, pts[0].y + i * paint.textSize * 1.2f, paint)
                }
                return
            }
            if (stroke.type == "rect" && pts.size >= 2) {
                canvas.drawRect(pts[0].x, pts[0].y, pts[1].x, pts[1].y, paint)
                return
            }
            if (stroke.type == "circle" && pts.size >= 2) {
                val rect = RectF(min(pts[0].x, pts[1].x), min(pts[0].y, pts[1].y),
                    max(pts[0].x, pts[1].x), max(pts[0].y, pts[1].y))
                canvas.drawOval(rect, paint)
                return
            }
            if (stroke.type in listOf("line", "arrow") && pts.size >= 2) {
                val a = pts.first(); val b = pts.last()
                canvas.drawLine(a.x, a.y, b.x, b.y, paint)
                if (stroke.type == "arrow") {
                    val angle = kotlin.math.atan2(b.y - a.y, b.x - a.x)
                    val length = 15f * (w / 700f)
                    for (sign in listOf(-1, 1)) {
                        val dir = angle + sign * .55f + Math.PI.toFloat()
                        canvas.drawLine(b.x, b.y,
                            b.x + length * kotlin.math.cos(dir),
                            b.y + length * kotlin.math.sin(dir), paint)
                    }
                }
                return
            }
            if (pts.size == 1) {
                canvas.drawPoint(pts[0].x, pts[0].y, paint)
                return
            }
            // Quadratic Bézier midpoint smoothing avoids jagged freehand ink.
            val path = Path().apply {
                moveTo(pts[0].x, pts[0].y)
                for (i in 1 until pts.size) {
                    val prev = pts[i - 1]; val next = pts[i]
                    quadTo(prev.x, prev.y, (prev.x + next.x) / 2f, (prev.y + next.y) / 2f)
                }
                lineTo(pts.last().x, pts.last().y)
            }
            canvas.drawPath(path, paint)
        }
    }
}
