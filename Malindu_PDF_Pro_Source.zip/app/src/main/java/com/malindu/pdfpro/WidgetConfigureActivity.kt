package com.malindu.pdfpro

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView

/** Shown when a widget is manually placed from the phone's widget picker. */
class WidgetConfigureActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        val widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID)
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.background)
            setPadding(Ui.dp(this@WidgetConfigureActivity, 18), Ui.dp(this@WidgetConfigureActivity, 20),
                Ui.dp(this@WidgetConfigureActivity, 18), 0)
        }
        setContentView(main)
        main.addView(Ui.label(this, "Choose your PDF widget", 23f, true))
        main.addView(Ui.label(this, "Tap a saved PDF to pin it to the Home Screen.",
            13f, color = Ui.subtle), Ui.margin(this, top = 8, bottom = 16))
        val scroller = ScrollView(this)
        val choices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(choices)
        main.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        val documents = Store(this).documents()
        if (documents.isEmpty()) {
            choices.addView(Ui.label(this, "No PDFs saved yet. Import one into the library first.",
                14f, color = Ui.subtle), Ui.margin(this, top = 10))
            choices.addView(Ui.button(this, "Open PDF library", true) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }, Ui.margin(this, top = 16))
        }
        documents.forEach { doc ->
            val row = Ui.card(this)
            row.addView(Ui.label(this, doc.title, 16f, true))
            row.addView(Ui.label(this, "Open instantly from your Home Screen",
                12f, color = Ui.subtle), Ui.margin(this, top = 6))
            row.setOnClickListener {
                QuickWidgetProvider.bind(this, widgetId, doc.uri, doc.title)
                setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                finish()
            }
            choices.addView(row, Ui.margin(this, bottom = 10))
        }
    }
}
