package com.malindu.pdfpro

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    val blue: Int = Color.rgb(49, 95, 234)
    val text: Int = Color.rgb(25, 35, 68)
    val subtle: Int = Color.rgb(106, 118, 149)
    val background: Int = Color.rgb(245, 247, 252)
    val lightBlue: Int = Color.rgb(232, 239, 255)
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + .5f).toInt()

    fun bg(color: Int, radius: Int, ctx: Context, stroke: Int = Color.TRANSPARENT): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(ctx, radius).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(ctx, 1), stroke)
        }
    }

    fun label(ctx: Context, content: String, size: Float = 15f, bold: Boolean = false,
              color: Int = text): TextView = TextView(ctx).apply {
        this.text = content
        textSize = size
        setTextColor(color)
        includeFontPadding = true
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    fun button(ctx: Context, title: String, emphasized: Boolean = false, action: () -> Unit): TextView =
        label(ctx, title, 13f, true, if (emphasized) Color.WHITE else blue).apply {
            background = bg(if (emphasized) blue else lightBlue, 13, ctx)
            setPadding(dp(ctx, 14), dp(ctx, 11), dp(ctx, 14), dp(ctx, 11))
            gravity = Gravity.CENTER
            minHeight = dp(ctx, 41)
            setOnClickListener { action() }
        }

    fun card(ctx: Context, padding: Int = 16): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(Color.WHITE, 18, ctx, Color.rgb(230, 234, 247))
        setPadding(dp(ctx, padding), dp(ctx, padding), dp(ctx, padding), dp(ctx, padding))
    }

    fun row(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun margin(ctx: Context, left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0):
            LinearLayout.LayoutParams = LinearLayout.LayoutParams(-1, -2).apply {
        setMargins(dp(ctx, left), dp(ctx, top), dp(ctx, right), dp(ctx, bottom))
    }

    fun space(ctx: Context, size: Int): View = View(ctx).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(ctx, size))
    }
}
