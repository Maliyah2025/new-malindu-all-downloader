package com.malindu.pdfpro

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import android.text.TextWatcher
import android.text.Editable

class MainActivity : Activity() {
    private val store by lazy { Store(this) }
    private lateinit var list: LinearLayout
    private lateinit var filter: EditText
    private var favoritesOnly = false
    private val openCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.background)
            setPadding(Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 16),
                Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 0))
        }
        setContentView(root)
        root.addView(Ui.label(this, "MALINDU  /  PDF PRO", 13f, true, Ui.blue))
        root.addView(Ui.label(this, "Your PDF workspace", 27f, true), Ui.margin(this, top = 7))
        root.addView(Ui.label(this, "Private • Offline • Fast • No ads", 12f, color = Ui.subtle),
            Ui.margin(this, top = 4))

        val controls = Ui.row(this)
        val add = Ui.button(this, "+  Open PDF", true) { choosePdf() }
        controls.addView(add, LinearLayout.LayoutParams(0, -2, 1f))
        val fav = Ui.button(this, "★  Favorites") {
            favoritesOnly = !favoritesOnly
            refresh()
        }
        controls.addView(fav, LinearLayout.LayoutParams(0, -2, 1f).apply {
            leftMargin = Ui.dp(this@MainActivity, 8)
        })
        root.addView(controls, Ui.margin(this, top = 20))

        filter = EditText(this).apply {
            singleLine = true
            textSize = 15f
            hint = "Search saved PDFs..."
            background = Ui.bg(android.graphics.Color.WHITE, 14, this@MainActivity)
            setPadding(Ui.dp(this@MainActivity, 15), Ui.dp(this@MainActivity, 11),
                Ui.dp(this@MainActivity, 15), Ui.dp(this@MainActivity, 11))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) { }
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh() }
                override fun afterTextChanged(s: Editable?) { }
            })
        }
        root.addView(filter, Ui.margin(this, top = 18))
        root.addView(Ui.label(this, "RECENT DOCUMENTS", 12f, true, Ui.subtle),
            Ui.margin(this, top = 20, bottom = 10))
        val scroll = ScrollView(this).apply { setFillViewport(false); isVerticalScrollBarEnabled = false }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        refresh()
    }

    private fun refresh() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val query = if (::filter.isInitialized) filter.text.toString().trim() else ""
        val items = store.documents().filter {
            it.title.contains(query, ignoreCase = true) && (!favoritesOnly || it.favorite)
        }
        if (items.isEmpty()) {
            val empty = Ui.card(this)
            empty.addView(Ui.label(this, "No PDFs here yet", 18f, true))
            empty.addView(Ui.label(this, "Use Open PDF to select a file from your phone or Telegram downloads.",
                14f, color = Ui.subtle), Ui.margin(this, top = 6))
            list.addView(empty, Ui.margin(this, top = 5))
            return
        }
        items.forEach { item ->
            val card = Ui.card(this)
            val titleRow = Ui.row(this)
            val icon = Ui.label(this, "▣", 27f, true, Ui.blue).apply { gravity = Gravity.CENTER }
            titleRow.addView(icon, LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 48)))
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(Ui.label(this, item.title, 15f, true).apply { maxLines = 2 })
            details.addView(Ui.label(this, "Page ${item.page + 1}   •   ${if (item.bookmarks.isEmpty()) "No bookmarks" else "${item.bookmarks.size} bookmarks"}",
                12f, color = Ui.subtle), Ui.margin(this, top = 4))
            titleRow.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            titleRow.addView(Ui.button(this, if (item.favorite) "★" else "☆") {
                item.favorite = !item.favorite
                store.save(item)
                refresh()
            })
            card.addView(titleRow)
            val row = Ui.row(this)
            val open = Ui.button(this, "Read", true) { read(item.uri) }
            row.addView(open, LinearLayout.LayoutParams(0, -2, 1f))
            val share = Ui.button(this, "Share") { share(Uri.parse(item.uri)) }
            row.addView(share, LinearLayout.LayoutParams(0, -2, 1f).apply {
                leftMargin = Ui.dp(this@MainActivity, 7)
            })
            val more = Ui.button(this, "More") { showMore(item) }
            row.addView(more, LinearLayout.LayoutParams(0, -2, 1f).apply {
                leftMargin = Ui.dp(this@MainActivity, 7)
            })
            card.addView(row, Ui.margin(this, top = 11))
            list.addView(card, Ui.margin(this, bottom = 10))
        }
    }

    private fun showMore(item: PdfItem) {
        AlertDialog.Builder(this).setTitle(item.title)
            .setItems(arrayOf("Open", "Add to favorites", "Remove from library")) { _, which ->
                when (which) {
                    0 -> read(item.uri)
                    1 -> { item.favorite = true; store.save(item); refresh() }
                    2 -> AlertDialog.Builder(this)
                        .setMessage("Remove from this app's library? Your original PDF will NOT be deleted.")
                        .setPositiveButton("Remove") { _, _ -> store.remove(item.uri); refresh() }
                        .setNegativeButton("Cancel", null).show()
                }
            }.show()
    }

    private fun read(s: String) {
        startActivity(Intent(this, ReaderActivity::class.java).apply { data = Uri.parse(s) })
    }

    private fun choosePdf() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, openCode)
    }

    @Deprecated("Compatible with Android 8+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == openCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { }
            store.ensure(uri)
            read(uri.toString())
        }
    }

    private fun share(uri: Uri) {
        try {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = android.content.ClipData.newUri(contentResolver, "PDF", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Share PDF"))
        } catch (e: Exception) { Toast.makeText(this, "Unable to share: ${e.message}", Toast.LENGTH_LONG).show() }
    }
}
