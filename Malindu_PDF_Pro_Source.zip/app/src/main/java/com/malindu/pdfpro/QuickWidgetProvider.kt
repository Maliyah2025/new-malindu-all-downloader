package com.malindu.pdfpro

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

class QuickWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        val edit = context.getSharedPreferences("pdf_widgets", Context.MODE_PRIVATE).edit()
        ids.forEach {
            edit.remove("uri_$it")
            edit.remove("title_$it")
        }
        edit.apply()
    }

    companion object {
        fun bind(context: Context, widgetId: Int, uri: String, title: String) {
            context.getSharedPreferences("pdf_widgets", Context.MODE_PRIVATE)
                .edit().putString("uri_$widgetId", uri).putString("title_$widgetId", title).apply()
            update(context, AppWidgetManager.getInstance(context), widgetId)
        }

        fun update(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val p = context.getSharedPreferences("pdf_widgets", Context.MODE_PRIVATE)
            val uri = p.getString("uri_$widgetId", null)
            val title = p.getString("title_$widgetId", "Open PDF")
            val views = RemoteViews(context.packageName, R.layout.pdf_widget)
            views.setTextViewText(R.id.widgetName, title ?: "Open PDF")
            val open = if (uri != null) {
                Intent(Intent.ACTION_VIEW, Uri.parse(uri), context, ReaderActivity::class.java).apply {
                    setDataAndType(Uri.parse(uri), "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } else Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(context, widgetId, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widgetRoot, pending)
            manager.updateAppWidget(widgetId, views)
        }
    }
}

/** The launcher sends the newly pinned widget ID to this PendingIntent. */
class WidgetPinnedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "com.malindu.pdfpro.WIDGET_PINNED") return
        val widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID)
        val uri = intent.getStringExtra("document_uri") ?: return
        val title = intent.getStringExtra("document_title") ?: "Open PDF"
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            QuickWidgetProvider.bind(context, widgetId, uri, title)
        }
    }
}
