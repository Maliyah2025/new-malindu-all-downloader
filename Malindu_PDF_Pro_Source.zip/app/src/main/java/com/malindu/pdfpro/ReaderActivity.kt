package com.malindu.pdfpro

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ClipData
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.PointF
import android.graphics.drawable.Icon
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.IOException
import kotlin.math.max
import kotlin.math.min

class ReaderActivity : Activity() {
    private lateinit var pdfUri: Uri
    private lateinit var renderer: PdfRenderer
    private lateinit var item: PdfItem
    private lateinit var view: InkPageView
    private lateinit var pageIndicator: TextView
    private lateinit var toolbarLabel: TextView
    private val store by lazy { Store(this) }
    private var currentPage = 0
    private var exportShareAfter = false
    private var exportPages: List<Int>? = null
    private val exportCode = 201
    private var fullscreen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = intent.data
        if (u == null) { finish(); return }
        pdfUri = u
        try {
            val fd = contentResolver.openFileDescriptor(pdfUri, "r")
                ?: throw IOException("Cannot access this document")
            renderer = PdfRenderer(fd)
            if (renderer.pageCount == 0) throw IOException("Empty PDF")
            item = store.ensure(pdfUri)
            currentPage = item.page.coerceIn(0, renderer.pageCount - 1)
            buildUi()
            loadPage(currentPage)
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Cannot open PDF")
                .setMessage("${e.message}\n\nUse Open PDF in the library to grant persistent file access. Password-protected or damaged PDFs may not open.")
                .setPositiveButton("Back") { _, _ -> finish() }
                .setOnCancelListener { finish() }.show()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.background)
        }
        setContentView(root)
        val heading = Ui.row(this).apply {
            setPadding(Ui.dp(this@ReaderActivity, 12), Ui.dp(this@ReaderActivity, 8),
                Ui.dp(this@ReaderActivity, 12), Ui.dp(this@ReaderActivity, 8))
        }
        heading.addView(Ui.button(this, "‹  Library") { finish() })
        val docInfo = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@ReaderActivity, 9), 0, Ui.dp(this@ReaderActivity, 2), 0)
        }
        docInfo.addView(Ui.label(this, item.title, 14f, true).apply {
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        })
        toolbarLabel = Ui.label(this, "Offline PDF editor", 11f, color = Ui.subtle)
        docInfo.addView(toolbarLabel)
        heading.addView(docInfo, LinearLayout.LayoutParams(0, -2, 1f))
        heading.addView(Ui.button(this, "↗ Share") { share(pdfUri) })
        root.addView(heading)

        view = InkPageView(this).apply {
            onInkChanged = { strokes -> store.saveStrokes(pdfUri.toString(), currentPage, strokes) }
            onPageSwipe = { step -> loadPage(currentPage + step) }
            onTextRequested = { p -> promptText(p) }
        }
        root.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))

        val navigation = Ui.row(this).apply {
            setPadding(Ui.dp(this@ReaderActivity, 12), Ui.dp(this@ReaderActivity, 7),
                Ui.dp(this@ReaderActivity, 12), Ui.dp(this@ReaderActivity, 7))
        }
        navigation.addView(Ui.button(this, "◀ Prev") { loadPage(currentPage - 1) })
        pageIndicator = Ui.label(this, "", 15f, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { jumpToPage() }
        }
        navigation.addView(pageIndicator, LinearLayout.LayoutParams(0, -2, 1f))
        navigation.addView(Ui.button(this, "Next ▶") { loadPage(currentPage + 1) })
        root.addView(navigation)

        val essential = toolsRow(root)
        tool(essential, "✎ Pen") { activate("pen") }
        tool(essential, "▰ Highlight") { activate("highlighter") }
        tool(essential, "⌫ Erase") { activate("eraser") }
        tool(essential, "✋ Move / Zoom") { activate("move") }
        tool(essential, "↶ Undo") { view.undo() }
        tool(essential, "↷ Redo") { view.redo() }
        tool(essential, "↻ Rotate PDF") { rotatePage() }
        tool(essential, "⤾ Rotate screen") { toggleScreenOrientation() }
        tool(essential, "● Ink color") { chooseColor() }
        tool(essential, "≋ Thickness") { chooseThickness() }

        val more = toolsRow(root)
        tool(more, "╱ Line") { activate("line") }
        tool(more, "▭ Rectangle") { activate("rect") }
        tool(more, "◯ Oval") { activate("circle") }
        tool(more, "↗ Arrow") { activate("arrow") }
        tool(more, "T Text") { activate("text") }
        tool(more, "★ Bookmark") { toggleBookmark() }
        tool(more, "☷ Bookmarks") { showBookmarks() }
        tool(more, "⇧ Home shortcut") { createHomeShortcut() }
        tool(more, "▣ Home widget") { pinHomeWidget() }
        tool(more, "⬇ Export edited") { beginExport(false) }
        tool(more, "✂ Extract pages") { extractPages() }
        tool(more, "↗ Export & share") { beginExport(true) }
        tool(more, "⋯ More") { showMoreTools() }
        activate("move")
    }

    private fun toolsRow(root: LinearLayout): LinearLayout {
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.WHITE)
        }
        val row = Ui.row(this).apply {
            setPadding(Ui.dp(this@ReaderActivity, 7), Ui.dp(this@ReaderActivity, 5),
                Ui.dp(this@ReaderActivity, 7), Ui.dp(this@ReaderActivity, 5))
        }
        scroll.addView(row)
        root.addView(scroll)
        return row
    }

    private fun tool(row: LinearLayout, label: String, click: () -> Unit) {
        row.addView(Ui.button(this, label, false, click), LinearLayout.LayoutParams(-2, -2).apply {
            rightMargin = Ui.dp(this@ReaderActivity, 6)
        })
    }

    private fun activate(tool: String) {
        view.changeMode(tool)
        toolbarLabel.text = if (tool == "move") "Read • Swipe pages • Pinch to zoom" else "Editing: $tool • Auto-save ON"
    }

    private fun loadPage(index: Int) {
        if (index !in 0 until renderer.pageCount) return
        try {
            val bitmap = synchronized(renderer) {
                val page = renderer.openPage(index)
                try {
                    val maxSide = max(page.width, page.height).coerceAtLeast(1)
                    val scale = min(2.4f, 2150f / maxSide)
                    val w = max(1, (page.width * scale).toInt())
                    val h = max(1, (page.height * scale).toInt())
                    Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { bitmap ->
                        Canvas(bitmap).drawColor(Color.WHITE)
                        val matrix = Matrix().apply { setScale(w.toFloat() / page.width, h.toFloat() / page.height) }
                        page.render(bitmap, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    }
                } finally { page.close() }
            }
            currentPage = index
            item.page = currentPage
            item.lastRead = System.currentTimeMillis()
            store.save(item)
            view.setPage(bitmap, store.strokes(pdfUri.toString(), currentPage), item.rotation)
            pageIndicator.text = "${index + 1} / ${renderer.pageCount}  ▾"
        } catch (e: Exception) {
            Toast.makeText(this, "Page error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun rotatePage() {
        item.rotation = (item.rotation + 90) % 360
        store.save(item)
        view.rotation = item.rotation
        Toast.makeText(this, "View rotated ${item.rotation}°. Original PDF unchanged.", Toast.LENGTH_SHORT).show()
    }

    private fun toggleScreenOrientation() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    private fun promptText(p: PointF) {
        val edit = EditText(this).apply {
            hint = "Text to place on PDF"
            setSingleLine(false)
            setPadding(Ui.dp(this@ReaderActivity, 18), Ui.dp(this@ReaderActivity, 14),
                Ui.dp(this@ReaderActivity, 18), Ui.dp(this@ReaderActivity, 14))
        }
        AlertDialog.Builder(this).setTitle("Insert text")
            .setView(edit)
            .setPositiveButton("Insert") { _, _ -> view.addText(p, edit.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun chooseColor() {
        val options = arrayOf("Blue", "Red", "Black", "Green", "Yellow", "Purple")
        val colors = intArrayOf(Color.rgb(49, 95, 234), Color.rgb(219, 43, 64), Color.BLACK,
            Color.rgb(29, 153, 96), Color.rgb(241, 180, 25), Color.rgb(132, 68, 212))
        AlertDialog.Builder(this).setTitle("Ink color")
            .setItems(options) { _, which -> view.penColor = colors[which] }.show()
    }

    private fun chooseThickness() {
        val bar = SeekBar(this).apply { max = 30; progress = view.strokeSize.toInt().coerceIn(1, 30) }
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@ReaderActivity, 16), 0, Ui.dp(this@ReaderActivity, 16), 0)
            addView(bar)
        }
        AlertDialog.Builder(this).setTitle("Pen / marker size")
            .setView(holder).setPositiveButton("Apply") { _, _ -> view.strokeSize = max(1, bar.progress).toFloat() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toggleBookmark() {
        if (!item.bookmarks.add(currentPage)) item.bookmarks.remove(currentPage)
        store.save(item)
        Toast.makeText(this, if (item.bookmarks.contains(currentPage)) "Page bookmarked" else "Bookmark removed", Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() {
        if (item.bookmarks.isEmpty()) {
            Toast.makeText(this, "No bookmarks. Tap ★ Bookmark on any page.", Toast.LENGTH_LONG).show()
            return
        }
        val pages = item.bookmarks.sorted()
        AlertDialog.Builder(this).setTitle("Bookmarks")
            .setItems(pages.map { "Page ${it + 1}" }.toTypedArray()) { _, which -> loadPage(pages[which]) }
            .setNegativeButton("Close", null).show()
    }

    private fun jumpToPage() {
        val edit = EditText(this).apply {
            hint = "1 – ${renderer.pageCount}"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setPadding(Ui.dp(this@ReaderActivity, 18), Ui.dp(this@ReaderActivity, 12),
                Ui.dp(this@ReaderActivity, 18), Ui.dp(this@ReaderActivity, 12))
        }
        AlertDialog.Builder(this).setTitle("Go to page").setView(edit)
            .setPositiveButton("Go") { _, _ ->
                val page = edit.text.toString().toIntOrNull()
                if (page != null && page in 1..renderer.pageCount) loadPage(page - 1)
                else Toast.makeText(this, "Enter a page from 1 to ${renderer.pageCount}", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showMoreTools() {
        AlertDialog.Builder(this).setTitle("Reading tools")
            .setItems(arrayOf("Go to page", "Fit page / reset zoom", "Full screen", "Adjust brightness", "PDF information", "Export edited PDF", "Night PDF view")) { _, choice ->
                when (choice) {
                    0 -> jumpToPage()
                    1 -> view.resetZoom()
                    2 -> toggleFullscreen()
                    3 -> chooseBrightness()
                    4 -> AlertDialog.Builder(this).setTitle("Document information")
                        .setMessage("${item.title}\n\nPages: ${renderer.pageCount}\nCurrent page: ${currentPage + 1}\nBookmarks: ${item.bookmarks.size}\nSaved privately, no cloud upload.\n\nAnnotations are stored locally until exported.")
                        .setPositiveButton("OK", null).show()
                    5 -> beginExport(false)
                    6 -> { view.nightMode = !view.nightMode }
                }
            }.show()
    }

    private fun toggleFullscreen() {
        fullscreen = !fullscreen
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (fullscreen) {
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        } else 0
    }

    private fun chooseBrightness() {
        val bar = SeekBar(this).apply { max = 100; progress = 75 }
        val holder = LinearLayout(this).apply {
            setPadding(Ui.dp(this@ReaderActivity, 16), 0, Ui.dp(this@ReaderActivity, 16), 0)
            addView(bar)
        }
        AlertDialog.Builder(this).setTitle("Reader brightness").setView(holder)
            .setPositiveButton("Apply") { _, _ ->
                val params = window.attributes
                params.screenBrightness = max(0.05f, bar.progress / 100f)
                window.attributes = params
            }.setNeutralButton("System default") { _, _ ->
                val params = window.attributes
                params.screenBrightness = -1f
                window.attributes = params
            }.show()
    }

    private fun share(uri: Uri) {
        try {
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(contentResolver, "PDF", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(share, "Share PDF quickly"))
        } catch (e: Exception) {
            Toast.makeText(this, "Share failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun createHomeShortcut() {
        val manager = getSystemService(ShortcutManager::class.java)
        if (!manager.isRequestPinShortcutSupported) {
            Toast.makeText(this, "Your launcher does not support pinned shortcuts", Toast.LENGTH_LONG).show()
            return
        }
        val open = Intent(Intent.ACTION_VIEW, pdfUri, this, ReaderActivity::class.java).apply {
            setDataAndType(pdfUri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val shortcut = ShortcutInfo.Builder(this, "pdf_${pdfUri.toString().hashCode()}")
            .setShortLabel(item.title.take(18))
            .setLongLabel(item.title.take(80))
            .setIcon(Icon.createWithResource(this, R.drawable.app_icon))
            .setIntent(open).build()
        val ok = manager.requestPinShortcut(shortcut, null)
        if (!ok) Toast.makeText(this, "Shortcut request was not accepted", Toast.LENGTH_LONG).show()
    }

    private fun pinHomeWidget() {
        val manager = AppWidgetManager.getInstance(this)
        if (!manager.isRequestPinAppWidgetSupported) {
            Toast.makeText(this, "Long-press Home Screen → Widgets → Malindu PDF Pro", Toast.LENGTH_LONG).show()
            return
        }
        val callback = Intent(this, WidgetPinnedReceiver::class.java).apply {
            action = "com.malindu.pdfpro.WIDGET_PINNED"
            data = Uri.parse("malindupdf://widget/${pdfUri.toString().hashCode()}")
            putExtra("document_uri", pdfUri.toString())
            putExtra("document_title", item.title)
        }
        val pending = PendingIntent.getBroadcast(this, pdfUri.toString().hashCode(), callback,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        val ok = manager.requestPinAppWidget(ComponentName(this, QuickWidgetProvider::class.java),
            null, pending)
        if (!ok) Toast.makeText(this, "Widget pinning unavailable. Add it from Home Screen widgets.", Toast.LENGTH_LONG).show()
    }

    private fun beginExport(shareWhenDone: Boolean) {
        exportPages = null
        exportShareAfter = shareWhenDone
        val title = item.title.substringBeforeLast(".") + "_annotated.pdf"
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, title)
        }, exportCode)
    }

    private fun extractPages() {
        val input = EditText(this).apply {
            hint = "e.g. 1-3, 5, 8-10"
            singleLine = true
            setPadding(Ui.dp(this@ReaderActivity, 18), Ui.dp(this@ReaderActivity, 12),
                Ui.dp(this@ReaderActivity, 18), Ui.dp(this@ReaderActivity, 12))
        }
        AlertDialog.Builder(this).setTitle("Extract selected pages")
            .setMessage("Enter PDF page numbers/ranges, separated by commas.")
            .setView(input).setPositiveButton("Save as PDF") { _, _ ->
                val pages = parsePages(input.text.toString())
                if (pages == null || pages.isEmpty()) {
                    Toast.makeText(this, "Invalid page range. Use 1-${renderer.pageCount}.", Toast.LENGTH_LONG).show()
                } else {
                    exportPages = pages
                    exportShareAfter = false
                    startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_TITLE,
                            item.title.substringBeforeLast(".") + "_extracted.pdf")
                    }, exportCode)
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun parsePages(input: String): List<Int>? {
        val pages = linkedSetOf<Int>()
        if (input.isBlank()) return null
        for (segment in input.split(',')) {
            val match = Regex("^(\\d+)\\s*(?:-\\s*(\\d+))?$").matchEntire(segment.trim()) ?: return null
            val first = match.groupValues[1].toIntOrNull() ?: return null
            val last = match.groupValues[2].takeIf { it.isNotEmpty() }?.toIntOrNull() ?: first
            if (first !in 1..renderer.pageCount || last !in first..renderer.pageCount) return null
            for (n in first..last) pages.add(n - 1)
        }
        return pages.toList()
    }

    @Deprecated("Compatible with Android 8+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == exportCode && resultCode == RESULT_OK) {
            val destination = data?.data ?: return
            val shareLater = exportShareAfter
            val chosenPages = exportPages?.toList()
            Toast.makeText(this, "Export started. Keep the PDF open until finished.", Toast.LENGTH_SHORT).show()
            Thread {
                try {
                    exportAnnotated(destination, chosenPages)
                    runOnUiThread {
                        Toast.makeText(this, "Annotated PDF saved successfully", Toast.LENGTH_LONG).show()
                        if (shareLater) share(destination)
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        AlertDialog.Builder(this).setTitle("Export failed")
                            .setMessage(e.message ?: "Please retry with available storage.")
                            .setPositiveButton("OK", null).show()
                    }
                }
            }.start()
        }
    }

    /** Export pages plus ink as a new PDF; preserves original, but rasterizes selectable text. */
    private fun exportAnnotated(destination: Uri, onlyPages: List<Int>? = null) {
        val outPdf = PdfDocument()
        try {
            synchronized(renderer) {
                val pages = onlyPages ?: (0 until renderer.pageCount).toList()
                for ((exportIndex, pageIndex) in pages.withIndex()) {
                    val src = renderer.openPage(pageIndex)
                    try {
                        val originalW = src.width.coerceAtLeast(1)
                        val originalH = src.height.coerceAtLeast(1)
                        val scale = min(2.0f, 2300f / max(originalW, originalH))
                        val bmpW = max(1, (originalW * scale).toInt())
                        val bmpH = max(1, (originalH * scale).toInt())
                        val bitmap = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
                        try {
                            Canvas(bitmap).drawColor(Color.WHITE)
                            src.render(bitmap, null, Matrix().apply {
                                setScale(bmpW.toFloat() / originalW, bmpH.toFloat() / originalH)
                            }, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                            val pageInfo = PdfDocument.PageInfo.Builder(originalW, originalH, exportIndex + 1).create()
                            val dst = outPdf.startPage(pageInfo)
                            try {
                                val dstCanvas = dst.canvas
                                dstCanvas.drawColor(Color.WHITE)
                                dstCanvas.drawBitmap(bitmap, null,
                                    RectF(0f, 0f, originalW.toFloat(), originalH.toFloat()),
                                    Paint(Paint.FILTER_BITMAP_FLAG))
                                store.strokes(pdfUri.toString(), pageIndex).forEach {
                                    InkPageView.drawStroke(dstCanvas, it,
                                        originalW.toFloat(), originalH.toFloat())
                                }
                            } finally { outPdf.finishPage(dst) }
                        } finally { bitmap.recycle() }
                    } finally { src.close() }
                }
            }
            contentResolver.openOutputStream(destination, "w")?.use { outPdf.writeTo(it) }
                ?: throw IOException("Cannot write to selected destination")
        } finally { outPdf.close() }
    }

    override fun onDestroy() {
        if (::view.isInitialized) view.clearPage()
        if (::renderer.isInitialized) {
            try { synchronized(renderer) { renderer.close() } } catch (_: Exception) { }
        }
        super.onDestroy()
    }
}
