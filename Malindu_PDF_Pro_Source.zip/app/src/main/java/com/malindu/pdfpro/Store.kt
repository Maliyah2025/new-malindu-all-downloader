package com.malindu.pdfpro

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.OpenableColumns
import android.graphics.PointF
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** All user data is kept on-device; no login, network or analytics. */
data class PdfItem(
    val uri: String,
    var title: String,
    var page: Int = 0,
    var favorite: Boolean = false,
    var lastRead: Long = System.currentTimeMillis(),
    var rotation: Int = 0,
    var bookmarks: MutableSet<Int> = mutableSetOf()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("uri", uri); put("title", title); put("page", page)
        put("favorite", favorite); put("lastRead", lastRead)
        put("rotation", rotation)
        put("bookmarks", JSONArray(bookmarks.sorted()))
    }

    companion object {
        fun fromJson(o: JSONObject): PdfItem {
            val marks = mutableSetOf<Int>()
            val a = o.optJSONArray("bookmarks") ?: JSONArray()
            for (i in 0 until a.length()) marks.add(a.optInt(i))
            return PdfItem(
                o.getString("uri"), o.optString("title", "Document.pdf"),
                o.optInt("page"), o.optBoolean("favorite"),
                o.optLong("lastRead", 0L), o.optInt("rotation"), marks
            )
        }
    }
}

data class InkStroke(
    var type: String,
    var color: Int,
    var size: Float,
    var points: MutableList<PointF> = mutableListOf(),
    var text: String = ""
) {
    fun deepCopy(): InkStroke = copy(points = points.map { PointF(it.x, it.y) }.toMutableList())
    fun toJson(): JSONObject = JSONObject().apply {
        put("type", type); put("color", color); put("size", size.toDouble()); put("text", text)
        val pts = JSONArray()
        points.forEach { pts.put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble())) }
        put("points", pts)
    }

    companion object {
        fun fromJson(o: JSONObject): InkStroke {
            val stroke = InkStroke(o.optString("type", "pen"), o.optInt("color"),
                o.optDouble("size", 4.0).toFloat(), text = o.optString("text"))
            val a = o.optJSONArray("points") ?: JSONArray()
            for (i in 0 until a.length()) {
                val xy = a.optJSONArray(i) ?: continue
                stroke.points.add(PointF(xy.optDouble(0).toFloat(), xy.optDouble(1).toFloat()))
            }
            return stroke
        }
    }
}

class Store(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("pdf_library_v1", Context.MODE_PRIVATE)

    fun documents(): MutableList<PdfItem> {
        val result = mutableListOf<PdfItem>()
        try {
            val a = JSONArray(prefs.getString("documents", "[]"))
            for (i in 0 until a.length()) result.add(PdfItem.fromJson(a.getJSONObject(i)))
        } catch (_: Exception) { }
        return result.sortedByDescending { it.lastRead }.toMutableList()
    }

    fun find(uri: String): PdfItem? = documents().firstOrNull { it.uri == uri }

    fun save(item: PdfItem) {
        val items = documents()
        items.removeAll { it.uri == item.uri }
        items.add(item)
        prefs.edit().putString("documents", JSONArray().apply {
            items.forEach { put(it.toJson()) }
        }.toString()).apply()
    }

    fun remove(uri: String) {
        val items = documents()
        items.removeAll { it.uri == uri }
        prefs.edit().putString("documents", JSONArray().apply {
            items.forEach { put(it.toJson()) }
        }.toString()).apply()
        // Removing a library entry intentionally does not delete user's original PDF.
    }

    fun ensure(uri: Uri): PdfItem {
        val key = uri.toString()
        val found = find(key)
        if (found != null) {
            found.lastRead = System.currentTimeMillis()
            save(found)
            return found
        }
        val item = PdfItem(key, displayName(uri))
        save(item)
        return item
    }

    fun displayName(uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) {
                    val ix = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ix >= 0) return it.getString(ix) ?: "Document.pdf"
                }
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "Document.pdf"
    }

    private fun inkFile(uri: String): File {
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(uri.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return File(ctx.filesDir, "ink_$hash.json")
    }

    fun strokes(uri: String, pageIndex: Int): MutableList<InkStroke> {
        val file = inkFile(uri)
        if (!file.exists()) return mutableListOf()
        try {
            val root = JSONObject(file.readText())
            val a = root.optJSONArray(pageIndex.toString()) ?: return mutableListOf()
            return MutableList(a.length()) { InkStroke.fromJson(a.getJSONObject(it)) }
        } catch (_: Exception) { return mutableListOf() }
    }

    fun saveStrokes(uri: String, pageIndex: Int, strokes: List<InkStroke>) {
        val file = inkFile(uri)
        val root = try { JSONObject(file.readText()) } catch (_: Exception) { JSONObject() }
        val a = JSONArray()
        strokes.forEach { a.put(it.toJson()) }
        root.put(pageIndex.toString(), a)
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(root.toString())
        if (!tmp.renameTo(file)) {
            file.writeText(root.toString())
            tmp.delete()
        }
    }
}
