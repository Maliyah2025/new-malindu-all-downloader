#!/usr/bin/env bash
set -euo pipefail
# Requires a locally installed Gradle 8.14, JDK 17, Android SDK 35.
gradle --no-daemon assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
