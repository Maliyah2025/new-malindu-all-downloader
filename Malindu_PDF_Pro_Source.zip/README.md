# Malindu PDF Pro — Native Android Offline PDF Reader

**Version:** 1.0.0 | **Package:** `com.malindu.pdfpro` | **Android:** 8.0+ (API 26)

A completely offline, native Android PDF app. No ads, login, internet permission, subscriptions, analytics, or cloud services. Written with Android's built-in `PdfRenderer`, `PdfDocument`, App Widget, and Shortcut APIs. No third-party PDF rendering library.

## Working features

- Open local PDFs via Android's system file picker (including Telegram downloads) or the system **Open with...** menu.
- Recent document library, search by filename, favorites, remember last page.
- Open/render multi-page PDFs, previous/next buttons, swipe page switching, jump to page, pinch-to-zoom (1–5×), double tap to toggle zoom, drag panning.
- **Rotate viewing orientation** 90° clockwise each tap, **rotate the screen** between portrait and landscape (original PDF untouched).
- **Smooth freehand Bézier pen**, translucent highlighter, stroke eraser, line, arrow, rectangle, oval, add text; ink colors and brush thickness.
- Automatic per-page local annotation saving, 40-step undo/redo for the current page.
- Bookmarks; full-screen reader, brightness adjustment, inverse/night PDF view, page info.
- Export PDF with annotations as a **new PDF** via Android's Save dialog; **extract page ranges** to a separate PDF. Export and share in one flow. Share original PDF directly.
- **Home Screen shortcut** targeting a specific PDF; real **Home Screen widget** selecting a saved PDF, including pin-widget flow on supported launchers.
- Share original PDF via Android Share Sheet, preserving content URI permissions.

## Important known limitations

- Export is **flattened/rasterized**: the original PDF is unchanged, but exported pages' text usually cannot be selected or searched. Exported files can be larger. Rendering is capped for memory efficiency.
- Original PDF text search, text selection, OCR, PDF merge/split, signatures and password removal are **not** implemented in v1. Do not advertise these as working.
- Annotations are stored in the app's private storage; uninstalling the app removes private annotations. Export annotated copies first, especially before uninstalling.
- The view-rotation setting is document-wide; export retains the **original page orientations** while including annotations.
- A system shortcut/widget requires the selected file to remain accessible. Use **Open PDF** in the app for persistent storage permissions. Documents shared temporarily using an external application's Open-with action might lose access after the grant expires.
- Pinning a widget depends on launcher support. If unsupported, long-press Home Screen → Widgets → Malindu PDF Pro → choose document.
- Password-protected, damaged, or provider-incompatible PDFs may be unsupported by the Android platform's PDF engine.
- Export of very long PDFs may be slow and needs free memory/storage. Keep the reader open during export.
- Android's page bitmap rendering is limited by memory and this app is not intended for sensitive high-assurance document storage.

## Build APK with GitHub Actions (easy; no PC needed)

1. Create an empty public/private GitHub repository, e.g. `Malindu-PDF-Pro`.
2. Upload **all files and folders INSIDE this ZIP** into the root of the repository, including `.github/workflows/android-apk.yml` (the dot-folder is hidden in some file browsers).
3. Commit to `main` (or `master`). The APK build will run automatically on push; you can also use **Actions → Build Malindu PDF Pro APK → Run workflow**.
4. When the workflow completes, open its run → **Artifacts** → **Malindu-PDF-Pro-APK**.
5. Download ZIP artifact, extract `app-debug.apk`, tap it on your phone to install (enable Install unknown apps when requested).

The debug APK uses GitHub's debug signing key. It is not a Play Store release. To publish/install reliable updates, configure your own signed release build and keep the same signing key.

## Build locally

Requires Java 17, Android SDK Platform 35, Android Gradle Plugin dependencies, Gradle 8.14, Kotlin Gradle Plugin 2.2.20 and internet on the build computer for initial dependencies. From project root:

```bash
gradle assembleDebug
```

Result: `app/build/outputs/apk/debug/app-debug.apk`.

## Data & privacy

- PDF file bytes are read with Android's system-provided file access (`ACTION_OPEN_DOCUMENT`).
- Recent file list, bookmarks and annotations are stored locally in Android private app data.
- App declares **zero Android permissions** and does not request Internet permission.
- No file is uploaded to any server by the app; explicit Share options invoke the user's chosen Android share destination.

## License

Source code supplied for user-owned customization and personal projects; built with platform Android SDK APIs.
